/**
 * NOT IN USE FOR �6
 *
 * Created by Jessica on 19.10.2015.
 */

function dokumentGeladen (e) {
    console.log("Seite geladen");
}

document.addEventListener("DOMContentLoaded", dokumentGeladen, false);

function playVid(id){
    switch(id){
        case "v1":
            document.getElementById("v1").play();
            break;
        case "v2":
            document.getElementById("v2").play();
            break;
        case "v3":
            document.getElementById("v3").play();
            break;
    }
}

function pauseVid(id){
    document.getElementById(id).pause();
    switch(id){
        case "v1":
            document.getElementById("v1").pause();
            break;
        case "v2":
            document.getElementById("v2").pause();
            break;
        case "v3":
            document.getElementById("v3").pause();
            break;
    }
}

function stopVid(id){
    switch(id){
        case "v1":
            document.getElementById("v1").load();
            break;
        case "v2":
            document.getElementById("v2").load();
            break;
        case "v3":
            document.getElementById("v3").load();
            break;
    }
}