/** Main app for server to start a small REST API for tweets
 * The included ./blackbox/store.js gives you access to a "database" which contains
 * already tweets with id 101 and 102, as well as users with id 103 and 104.
 * On each restart the db will be reset (it is only in memory).
 * Best start with GET http://localhost:3000/tweets to see the JSON for it
 *
 * @author Johannes Konert, edit by Gruppe 27, Lukas Danke, Jessica Becker, Maurice Stolte
 * @licence CC BY-SA 4.0
 *
 */
"use strict";

// node module imports
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');

// own modules imports
var store = require('./blackbox/store.js');


// creating the server application
var app = express();

// Middleware ************************************
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// logging
app.use(function(req, res, next) {
    console.log('Request of type '+req.method + ' to URL ' + req.originalUrl);
    next();
});

// API-Version control. We use HTTP Header field Accept-Version instead of URL-part /v1/
app.use(function(req, res, next){
    // expect the Accept-Version header to be NOT set or being 1.0
    var versionWanted = req.get('Accept-Version');
    if (versionWanted !== undefined && versionWanted !== '1.0') {
        // 406 Accept-* header cannot be fulfilled.
        res.status(406).send('Accept-Version cannot be fulfilled').end();
    } else {
        next(); // all OK, call next handler
    }
});

// request type application/json check
app.use(function(req, res, next) {
    if (['POST', 'PUT'].indexOf(req.method) > -1 &&
        !( /application\/json/.test(req.get('Content-Type')) )) {
        // send error code 415: unsupported media type
        res.status(415).send('wrong Content-Type');  // user has SEND the wrong type
    } else if (!req.accepts('json')) {
        // send 406 that response will be application/json and request does not support it by now as answer
        // user has REQUESTED the wrong type
        res.status(406).send('response of application/json only supported, please accept this');
    }
    else {
        next(); // let this request pass through as it is OK
    }
});


// Routes ***************************************
/*

 /tweets - get,post

 */
app.route('/tweets')
    .get(function(req,res,next) {
        //basic path for href
        var path = req.protocol + '://' + req.headers.host;
        //current data
        var myJson = {items:JSON.parse(JSON.stringify(store.select('tweets')))};
        for(var i=0; i<myJson.items.length;i++) {
            //current tweet
            var curTweet = myJson.items[i];
            //set href and user-href
            curTweet.href = path + '/tweets/' + curTweet.id;
            curTweet.creator.href = path + '/users/' + curTweet.creator.id;
        }
        res.json(myJson);
    })
    .post(function(req,res,next) {
        var path = req.protocol + '://' + req.headers.host;
        var myJson = req.body;
        //check 406 invalids
        if (myJson == undefined || myJson.message == undefined || myJson.creator.id == undefined) {
            res.status(406).end();
        }
        else{
            //user object
            var user = store.select('users', myJson.creator.id);
            //check 406 invalids
            if (user = undefined) {
                res.status(406).end();
            }
            else{
                myJson = {message: req.body.message, creator: {id: myJson.creator.id}};
                var id = store.insert('tweets', myJson);
                user.tweets.push(id);
                store.replace('users', myJson.creator.id, user);
                //Build Json + href references
                myJson.creator.href = path + '/users/' + myJson.creator.id;
                myJson.href = path + req.originalUrl + '/' + id;
                // 201 = created + return item
                res.status(201).json(myJson);
            }
        }
    });
/*

 /tweets/:id - get,delete,put

 */
app.route('/tweets/:id')
    .get(function(req,res,next) {
        var tweet = store.select('tweets', req.params.id);
        //tweets exists??? | 404
        if(tweet == undefined){
            res.status(404).end();
        }
        else{
            var path = req.protocol + '://' + req.headers.host;
            var myJson = JSON.parse(JSON.stringify(tweet));
            //link href
            myJson.href = path + req.originalUrl;
            myJson.creator.href = path + '/users/' + myJson.creator.id;
            //return modified Json
            res.json(myJson);
        }
    })
    .delete( function(req,res,next) {
        var tweet = store.select('tweets', req.params.id);
        //tweets exists??? | 404
        if (tweet == undefined)
            res.status(404).end();
        else {
            var user = store.select('users', tweet.creator.id);
            //user exists & the tweet in user
            if(user != undefined && user.tweets.indexOf(parseInt(req.params.id)) >= 0) {
                //remove the reference from user
                user.tweets.splice(user.tweets.indexOf(parseInt(req.params.id)), 1);
                store.replace('users', tweet.creator.id, user);
            }
            store.remove('tweets', req.params.id);
            res.status(200).end();
        }
    })
    .put(function(req,res,next) {
        //tweets exists??? | 404
        if (store.select('tweets', req.params.id) == undefined)
            res.status(404).end();
        else {
            store.replace('tweets', req.params.id, req.body);
            res.status(200).end();
        }
    });

/*

 Route: users - get,post

 */
app.route('/users')
    .get(function(req,res,next){
        var path = req.protocol + '://' + req.headers.host;
        var myJson = {items:JSON.parse(JSON.stringify(store.select('users')))};
        for(var i=0; i<myJson.items.length;i++) {
            var user = myJson.items[i];
            //link href
            user.href = path + '/users/' + user.id;
            //link tweets from user
            user.tweets = {href: user.href + '/tweets'};
        }
        res.json(myJson);
    })
    .post( function(req,res,next) {
        //check 406 invalids
        if(req.body == undefined || req.body.firstname == undefined || req.body.lastname == undefined) {
            res.status(406).end();
        }
        else {
            var myJson = {firstname:req.body.firstname,lastname:req.body.lastname};
            var id = store.insert('users', myJson);
            // 201 - create item + return
            res.status(201).json(store.select('users', id));
        }
    });

/*

 Route: users/:id - get,delete,put

 */
app.route('/users/:id')
    .get( function(req,res,next) {
        //user exists??? | 404
        var obj = store.select('users', req.params.id);
        if(obj == undefined) {
            res.status(404).end();
        }
        else{
            var path = req.protocol + '://' + req.headers.host;
            var myJson = JSON.parse(JSON.stringify(obj));
            /* Zusatz 2b.
            expanded = req.expand
            if(expanded){
                tweetList t = [];
                for(i=0;i<){
                    //add refs
                    //add to t

                }
                myJson.tweets.items = t
             }
             */
            //link href
            myJson.href = path + req.originalUrl;
            //link tweets from user
            myJson.tweets = {href: path + req._parsedUrl.pathname + '/tweets'};
            res.json(myJson);
        }
    })
    .delete(function(req,res,next) {
        //user exists??? | 404
        var user = store.select('users', req.params.id);
        if (user == undefined) {
            res.status(404).end();
        }
        else{
            //checks tweets from user
            if(user.tweets != undefined) {
                //remove all tweets from the user
                for(var i=0; i<user.tweets.length;i++) {
                    var reqTweet = store.select('tweets', user.tweets[i]);
                    //safe check
                    if (reqTweet != undefined) {
                        store.remove('tweets', user.tweets[i]);
                    }
                }
            }
            store.remove('users', req.params.id);
            res.status(204).end();
        }
    })
    .put(function(req,res,next) {
        //user exists??? | 404
        if (store.select('users', req.params.id) == undefined)
            res.status(404).end();
        else {
            //user correct??? | 406
            if(req.body == undefined || req.body.firstname == undefined || req.body.lastname == undefined
                || req.body.id == undefined || req.body.tweets == undefined || req.body.id != req.params.id)
                res.status(406).end();
            else {
                //replace user if all data correct
                store.replace('users', req.params.id, myJson);
                res.status(200).end();
            }
        }
    });

// TODOs
// TODO: some HTTP error responses in case not found
// TODO generate for each entity on response the proper href: .. property

// CatchAll for the rest (unfound routes/resources ********

// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers (express recognizes it by 4 parameters!)

// development error handler
// will print stacktrace as JSON response
if (app.get('env') === 'development') {
    app.use(function(err, req, res, next) {
        console.log('Internal Error: ', err.stack);
        res.status(err.status || 500);
        res.json({
            error: {
                message: err.message,
                error: err.stack
            }
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.json({
        error: {
            message: err.message,
            error: {}
        }
    });
});


// Start server ****************************
app.listen(3000, function(err) {
    if (err !== undefined) {
        console.log('Error on startup, ',err);
    }
    else {
        console.log('Listening on port 3000');
    }
});