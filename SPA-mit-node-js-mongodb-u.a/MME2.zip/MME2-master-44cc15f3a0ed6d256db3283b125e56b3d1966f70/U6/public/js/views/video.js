/**
 * VideoView for backbone.js
 *
 * Created by Luke on 13.01.2016.
 */
define(['backbone', 'jquery', 'underscore'], function(Backbone, $, _) {
    var VideoView = Backbone.View.extend({
        tagName: 'vid',
        className: 'video',
        template: _.template($('#video-template').text()),
        render: function() {
            this.$el.html(this.template(this.model.attributes));
            return this;
        },
        initialize: function() {
            this.listenTo(this.model, 'change', this.render);
        }
    });
    return VideoView;
});