/**
 * Created by Luke/Gruppe 27 on 16.12.2015.
 */


var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var VideoSchema = new Schema({
    title: {type: String, required: true},
    description: {type:String ,required: false,  default: " "},
    src: {type: String, required: true},
    length: {type: Number, required: true, min: 0 },
    playcount: {type: Number, required: false, default: 0, min: 0 },
    ranking: {type: Number, required: false, default: 0, min: 0}

},{
    timestamps:  {createdAt: 'timestamp'}
});

module.exports = mongoose.model('videos',VideoSchema);
