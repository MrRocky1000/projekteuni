/**
 * @author Created by Gruppe 27
 *
 * video.js . backbone modals of videos
 * connect to REST-API /videos
 *
 */
define(['backbone', 'underscore'], function(Backbone, _) {
    var result = {};
    var videoSchema = {
        urlRoot: '/videos', // not really needed if collection exists
        idAttribute: "_id",
        defaults: {
            title: "",
            description: "",
            src: "",
            length: 0,
            playcount: 0,
            ranking: 0,
            timestamp: ''
        },
        initialize: function() {
            // after constructor code
        },
        validate: function(attr) {
            if ( _.isEmpty(attr.title) ) {
                return "Missing Title";
            }
            if ( _.isEmpty(attr.src) ) {
                return "Missing Source";
            }
            if (_.isEmpty(attr.length)) {
                return "Missing Length";
            }
            if(attr.length < 0){
                return "Length has to be > 0"
            }
            if(attr.playcount < 0){
                return "Playcount has to be > 0"
            }
            if(attr.ranking < 0){
                return "ranking has to be > 0"
            }
        }
    };

    var VideoModel = Backbone.Model.extend(videoSchema);

    var VideoCollection = Backbone.Collection.extend({
        model: VideoModel,
        url: '/videos',
        initialize: function() {
            this.on('add', function(video) {
                if (video.isValid() && video.isNew()) {
                    video.save();
                }
            })
        }
    });

    result.Model = VideoModel;
    result.Collection = VideoCollection;
    return result;
});