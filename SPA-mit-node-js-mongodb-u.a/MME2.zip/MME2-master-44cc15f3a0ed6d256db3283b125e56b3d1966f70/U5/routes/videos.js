/** This module defines the routes for videos using a mongoose model
 *
 * @author Johannes Konert @edited by Gruppe 27
 * @licence CC BY-SA 4.0
 *
 * @module routes/videos
 * @type {Router}
 */

// remember: in modules you have 3 variables given by CommonJS
// 1.) require() function
// 2.) module.exports
// 3.) exports (which is module.exports)

// modules
var express = require('express');
var logger = require('debug')('me2u5:videos');

var mongoose = require('mongoose');
var db = mongoose.connect('mongodb://localhost:27017/me2');
var VideoModel = require('../models/videos');

var videos = express.Router();


// routes **********************
videos.route('/')
    .get(function(req, res, next) {
        /*
        VideoModel.find({},function(err,items){
            //M�glicher DB-Error soll nicht gehandelt werden
            if(!err) {
                res.status(200).json(items);
            }
        });
        */
        //ZUSATZ 5
        var limit, offset = 0;
        if(req.query.offset != undefined && parseInt(req.query.offset) > 0){// wenn -1 nicht von mongoose gehandelt:
            offset = parseInt(req.query.offset);
        }
        if(req.query.limit != undefined){
            limit = parseInt(req.query.limit);
        }
        VideoModel.
            find({}).
            skip(offset).
            limit(limit).
            exec(function(err,items){
                if(!err){
                    res.status(200).json(items);
                }
            });

    })
    .post(function(req,res,next) {
        req.body.timestamp = new Date().getTime();
        var video = new VideoModel(req.body);
        video.save(function(err){
           if(!err){
               res.status(201).json(video);
           }
            else{
               res.status(400).json({error:{message:"Required keys not found",code:400}});
           }
        });
    })
    .all(function(req, res, next) {
        if (res.locals.processed) {
            next();
        } else {
            // reply with wrong method code 405
            var err = new Error('this method is not allowed at ' + req.originalUrl);
            //err.status = codes.wrongmethod;
            next(err);
        }
    });

videos.route('/:id')
    .get(function(req, res,next) {
        var filter = req.query.filter;
        if(filter == undefined){
            VideoModel.findById(req.params.id,function(err,item){
                if(item != null){
                    res.status(200).json(item);
                }
                else{
                    res.status(404).json({error:{message:"Video does not exist",code:404}});
                }
            });
        }//ZUSATZ 4 FILTER
        else{
            var filterList = req.query.filter.split(",");
            var filters = "";
            for(var f in filterList){
                var fo = filterList[f];
                if( fo == "_id" || fo == "title" || fo == "description" || fo == "src" || fo == "length" || fo == "timestamp" || fo == "playcount" || fo == "ranking"){
                    if(!(filters == "")){
                        filters += " "+fo;
                    }
                    else{
                        filters = fo;
                    }
                }
                else{
                    res.status(400).json({error:{message:"Invalid filter",code:400}});
                }

            }
            console.log(filters);
            VideoModel.find({"_id": req.params.id},filters,function(err,item){
                if(!err){
                    res.status(200).json(item);
                }
                else{
                    res.status(404).json({error:{message:"Video does not exist",code:404}});
                }
            });
        }
    })
    .put(function(req, res,next) {
        if (req.params.id == req.body._id) {
            VideoModel.findById(req.params.id,function(err,item){
                if(!err){
                    for(var attr in item.schema.paths){
                        switch(attr){
                            case('title'):
                                //parsInt ... . attr
                                item[attr] = req.body.title;
                                break;
                            case('description'):
                                if(req.body.playcount == undefined){
                                    attr = "";
                                    break;
                                }
                                else{
                                    attr = req.body.description;
                                    break;
                                }
                            case('src'):
                                attr = req.body.src;
                                break;
                            case('length'):
                                attr = req.body.length;
                                break;
                            case('playcount'):
                                if(req.body.playcount < 0 || req.body.playcount == undefined){
                                    attr = 0;
                                    break;
                                }
                                else{
                                    attr = req.body.playcount;
                                    break;
                                }
                            case('ranking'):
                                if(req.body.ranking < 0 || req.body.ranking == undefined){
                                    attr = 0;
                                    break;
                                }
                                else{
                                    attr = req.body.ranking;
                                    break;
                                }
                            case('timestamp'):
                                attr = new Date().getTime();
                                break;
                        }
                    }
                    item.save(function(err){
                        if(!err){
                            res.status(201).json(item);
                        }
                        else{
                            res.status(400).json({error:{message:"Required keys not found",code:400}});
                        }
                    });
                }
                else{
                    res.status(404).json({error:{message:"Video does not exist",code:404}});
                }
            });
        }
        else {
            var err = new Error('id of PUT resource and send JSON body are not equal ' + req.params.id + " " + req.body.id);
            //err.status = codes.wrongrequest;
            next(err);
        }
    })
    .delete(function(req,res,next) {
        /*
        if(req.params.id != req.body.id){
            var err = new Error('id of PUT resource and send JSON body are not equal ' + req.params.id + " " + req.body.id);
            err.status = codes.wrongrequest;
            next(err);
        }
        */
        VideoModel.findByIdAndRemove(req.params.id,function(err,item){
            if(!err){
                res.status(204);
            }
            else{
                res.status(404).json({error: {message: "Video does not exist", code: 404}});
            }
        });
     })
    .patch(function(req,res,next) {
        VideoModel.findByIdAndUpdate(req.params.id, req.body, {new: true}, function(err, item) {
            if(!err){
                res.status(200).json(item);
            }
            else{
                res.status(404).json({error: {message: "Video does not exist", code: 404}});
            }
        });
    })

    .all(function(req, res, next) {
        if (res.locals.processed) {
            next();
        } else {
            // reply with wrong method code 405
            var err = new Error('this method is not allowed at ' + req.originalUrl);
           // err.status = codes.wrongmethod;
            next(err);
        }
    });


// this middleware function can be used, if you like or remove it
// it looks for object(s) in res.locals.items and if they exist, they are send to the client as json
videos.use(function(req, res, next){
    // if anything to send has been added to res.locals.items
    if (res.locals.items) {
        // then we send it as json and remove it
        res.json(res.locals.items);
        delete res.locals.items;
    } else {
        // otherwise we set status to no-content
        res.set('Content-Type', 'application/json');
        res.status(204).end(); // no content;
    }
});

module.exports = videos;