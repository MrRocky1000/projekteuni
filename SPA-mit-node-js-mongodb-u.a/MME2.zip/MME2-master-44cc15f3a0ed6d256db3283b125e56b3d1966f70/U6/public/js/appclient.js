/** Main application file to start the client side single page app for videos
 *
 * @author Johannes Konert @edited by Gruppe 27
 */

requirejs.config({
    baseUrl: "/js",
    paths: {
        jquery: './_lib/jquery-1.11.3',
        underscore: './_lib/underscore-1.8.3',
        backbone: './_lib/backbone-1.2.3'
    },
    shim: {
        underscore: {
            exports: "_"
        },
        backbone: {
            deps: ['underscore', 'jquery'],
            exports: 'Backbone'
        }
    }
});

// AMD conform require as provided by require.js
require(['jquery','backbone','models/video','views/video', 'views/video-list'],
        function($, Backbone, Videos, VideoView, VideoListView) {

    var AppRouter = Backbone.Router.extend({
        routes: {
            '': 'main',
            '*whatever': 'main'
        },
        main: function(){
            //----------TEST----------
            $('body').prepend('<h1>Video App</h1>');
            //----------VIDEO----------
            //Hard coded ID from first video in collection
            var video = new Videos.Model({_id: "567297b25afe14c8138fb3a3"});
            var videoView = new VideoView({model: video});

            video.fetch({
                success: function(){
                    $('body').append(videoView.render().el);
                },
                error: function(){
                    alert("ERROR");
                }
            });


            //----------VIDEOLIST----------


            var videos = new Videos.Collection();
            var videoListView = new VideoListView({collection: videos});
            //unn�tzer Code nach fetch durch "add" Methode in video-list, hier f�r Abnahme
            videos.fetch({
                error: function(){
                    alert("ERRORLIST");
                },
                success: videoListView.render
            });
        }
    });

    var myRouter = new AppRouter();

    // finally start tracking URLs to make it a SinglePageApp (not really needed at the moment)
    Backbone.history.start({pushState: true}); // use new fancy URL Route mapping without #
});
