/** This module defines the routes for videos using the store.js as db memory
 *
 * @author Johannes Konert @ edited by Gruppe 27
 * @licence CC BY-SA 4.0
 *
 * @module routes/videos
 * @type {Router}
 */

// remember: in modules you have 3 variables given by CommonJS
// 1.) require() function
// 2.) module.exports
// 3.) exports (which is module.exports)

// modules
var express = require('express');
var logger = require('debug')('me2u4:videos');
var store = require('../blackbox/store');

var videos = express.Router();

// if you like, you can use this for task 1.b:
var requiredKeys = {title: 'string', src: 'string', length: 'number'};
var optionalKeys = {description: 'string', playcount: 'number', ranking: 'number'};
var internalKeys = {id: 'number', timestamp: 'number'};


// routes **********************
/*
 videos without id - get,post - delete,put not allowed
 */
videos.route('/')
    .get(function(req, res, next) {
        // Aufgabe 1 : res.status(200).json(store.select('videos'));
        var data = store.select('videos');
        var back = [];
        //defaults
        var offset = 0;
        var limit = data.length;
        //check query, wenn nicht vorhanden --> defaults f�r offset+limit
        if(req.query.offset != undefined){
            offset = parseInt(req.query.offset);
        }
        if(req.query.limit != undefined){
            limit = parseInt(req.query.limit);
        }
        //checkt alle m�glichen Fehlerquellen
        if(isNaN(offset) || isNaN(limit) || offset < 0 || limit <=0 || offset >= data.length){
            res.status(400).json({error:{message:"Invalid Value",code:400}});
        }
        else{
            //f�llt das array, mit der maximal angegebenen Gr��e
            back = [limit];
            for(var i = 0; i < limit && offset+i < data.length;i++ ){
                back[i]= data[i+offset];
            }
            res.status(200).json(back);
        }
    })
    .post(function(req,res,next) {
        //check requiredKeys
        var valid = true;
        Object.keys(requiredKeys).forEach(function(key) {
            if ((typeof req.body[key]) != requiredKeys[key]) {
                valid = false;
            }
        });
        //Wenn ein requiered key nicht gefunden wird
        if(!valid)
            res.status(400).json({error:{message:"Required keys not found",code:400}});
        else{
            req.body.timestamp = new Date().getTime();
            //optionale keys checken, wenn nicht vorhanden: defaults setzen
            if(!req.body.description || (typeof req.body.description) != optionalKeys.description){
                req.body.description = '';
            }
            if(!req.body.playcount || (typeof req.body.playcount) != optionalKeys.playcount){
                req.body.playcount = 0;
            }
            if(!req.body.ranking || (typeof req.body.ranking) != optionalKeys.ranking){
                req.body.ranking = 0;
            }
            var id = store.insert('videos', req.body);
            res.status(201).json(store.select('videos', id));
        }
    })
    .delete(function(req,res,next){
        res.status(405).json({error:{message:"Not allowed",code:405}});
    })
    .put(function(req,res,next) {
        res.status(405).json({error:{message:"Not allowed",code:405}});
    });
/*
 videos with id - get,delete,put - post not allowed
 */
videos.route('/:id')
    .get(function(req, res, next) {
        var obj = store.select('videos',req.params.id);
        //objekt exisistenz pr�fen
        if (obj == undefined){
            res.status(404).json({error:{message:"Video does not exist",code:404}});
        }
        else{
            var filter = req.query.filter;
            //wenn keine filter --> normales Objekt zur�ckgeben
            if(filter != undefined){
                //defaults
                var check = true;
                var newJson = {};
                //filter in array aufteilen, um es bearbeiten zu k�nnen + array durchgehen
                var filters = req.query.filter.split(",");
                for(var f in filters){
                    if(!obj[filters[f]]){
                        check = false;
                        break;
                    }
                    else{
                        newJson[filters[f]]= obj[filters[f]];
                    }
                }
                if(check){
                    res.status(200).json(newJson);
                }
                else{
                    res.status(400).json({error:{message:"Invalid filter",code:400}});
                }
            }
            else{
                res.status(200).json(obj);
            }
        }
    })
    .post(function(req,res,next) {
        res.status(405).json({error:{message:"Not allowed",code:405}});
    })
    .delete(function(req,res,next){
        //l�schen, wenn Objekt existiert
        var obj = store.select('videos', req.params.id);
        if(obj == undefined) {
            res.status(404).json({error: {message: "Video does not exist", code: 404}});
        }
        else{
            store.remove('videos', req.params.id);
            next(); //warum nicht mit status 204???
        }
    })
    .put(function(req,res,next) {
        //check requiredKeys
        var valid = true;
        Object.keys(requiredKeys).forEach(function(key) {
            if (!req.body[key] || (typeof req.body[key]) != requiredKeys[key]) {
                valid = false;
            }
        });
        //Wenn ein requiered key nicht gefunden wird
        if(!valid) {
            res.status(400).json({error: {message: "Required keys not found", code: 400}});
        }
        else {
            store.replace('videos', req.body.id, req.body);
            res.status(200).json(store.select('videos',req.body.id));
        }
    });

// this middleware function can be used, if you like or remove it
videos.use(function(req, res, next){
    // if anything to send has been added to res.locals.items
    if (res.locals.items) {
        // then we send it as json and remove it
        res.json(res.locals.items);
        delete res.locals.items;
    } else {
        // otherwise we set status to no-content
        res.set('Content-Type', 'application/json');
        res.status(204).end(); // no content;
    }
});

module.exports = videos;
